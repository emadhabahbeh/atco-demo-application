package com.example.demo.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import javax.persistence.*;
@Entity
@Table
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class TestEntity {
   @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
   private Long id;
    @Column(name = "id")
    private String Name;

//    private List<InvoiceLines>  invoiceLines;

}
