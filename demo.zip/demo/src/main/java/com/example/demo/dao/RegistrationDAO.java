package com.example.demo.dao;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@AllArgsConstructor
@Getter
@Setter

public class RegistrationDAO {
    private String username;
    private String password;
    private String email;
    private String Address;
}
