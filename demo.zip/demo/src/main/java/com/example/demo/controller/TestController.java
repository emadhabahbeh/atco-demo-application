package com.example.demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import javax.persistence.Id;
import lombok.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
@RestController
public class TestController {
    @GetMapping("/TestDatabase")
    public List<CustomerTransaction> getAllCustomerTrx() {
        List<CustomerTransaction> customerTrxList = new ArrayList<>();
        try {
            String dbURL = "jdbc:oracle:thin:@194.163.169.38:1521:ebs_tstpdb";
            String strUserID = "system";
            String strPassword = "maneger";
            Connection myConnection = DriverManager.getConnection(dbURL, strUserID, strPassword);
            Statement sqlStatement = myConnection.createStatement();
            String readRecordSQL = "select e.name from xx_employee e";
            ResultSet myResultSet = sqlStatement.executeQuery(readRecordSQL);

            while (myResultSet.next()) {
                CustomerTransaction transaction = new CustomerTransaction();
                transaction.setColumnName(myResultSet.getString("id"));
                customerTrxList.add(transaction);
            }
            myResultSet.close();
            myConnection.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return customerTrxList;
    }
    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    private class CustomerTransaction {
//        private long Name;
        private String columnName;

    }
}







