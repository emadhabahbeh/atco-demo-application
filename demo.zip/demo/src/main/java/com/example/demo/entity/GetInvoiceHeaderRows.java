package com.example.demo.entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.List;

public class GetInvoiceHeaderRows implements CommandLineRunner{

    @Autowired
    private JdbcTemplate jdbcTemplate;
    private List<InvoiceLines> invoiceLines;

}
