package com.example.demo.dao;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@AllArgsConstructor
@Getter
@Setter

public class ContactDAO {
    private String Contact;

}
