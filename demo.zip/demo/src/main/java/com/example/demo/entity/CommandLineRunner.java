package com.example.demo.entity;

public interface CommandLineRunner {
}
