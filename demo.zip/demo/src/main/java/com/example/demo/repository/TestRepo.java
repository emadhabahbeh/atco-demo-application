package com.example.demo.repository;

import com.example.demo.entity.TestEntity;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface TestRepo extends CrudRepository<TestEntity, Long> {
    @Query( "select e.name from xx_employee e")
    List<TestEntity> findByColumnName(@Param("id") String ColumName);
}